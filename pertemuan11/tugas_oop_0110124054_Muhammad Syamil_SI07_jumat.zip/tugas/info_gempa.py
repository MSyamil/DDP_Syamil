from Gempa import *

gempa1 = gempa("Banten", 1.2)
gempa1.dampak()

gempa2 = gempa("Palu", 6.1)
gempa2.dampak()

gempa3 = gempa("Cianjur", 5.6)
gempa3.dampak()

gempa4 = gempa("Jayapura", 3.3)
gempa4.dampak()

gempa5 = gempa("Garut", 4.0)
gempa5.dampak()